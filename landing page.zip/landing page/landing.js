document.addEventListener('DOMContentLoaded', function() {
    const hero = document.querySelector('.hero');
    const images = ['images/hero-background1.jpg', 'images/hero-background2.jpg', 'images/hero-background3.jpg'];
    let currentIndex = 0;

    function changeBackground() {
        currentIndex = (currentIndex + 1) % images.length;
        hero.style.backgroundImage = `url(${images[currentIndex]})`;
    }

    setInterval(changeBackground, 5000); // Change background every 5 seconds
});
